﻿namespace DatabaseComponent {
  
   

}

namespace DatabaseComponent {
    
    
    public partial class NorthwindDataSet {
    }
}
