﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Diagnostics;

namespace CustomSqlLoggingModule
{
    public class SimpleSqlLogging : IHttpModule
    {
        private HttpApplication _CurrentApplication;

        public void Dispose()
        {
            _CurrentApplication = null;
        }

        public void Init(HttpApplication context)
        {
            // Attache to the incoming request event
            _CurrentApplication = context;
            if (context != null)
            {
                context.BeginRequest += new EventHandler(context_BeginRequest);
            }
        }

        void context_BeginRequest(object sender, EventArgs e)
        {
            try
            {
                // Write a log entry to the database
                SimpleLoggingDataSetTableAdapters.WebLoggingTableAdapter adapter =
                    new SimpleLoggingDataSetTableAdapters.WebLoggingTableAdapter();

                adapter.Insert(
                    Guid.NewGuid(),
                    DateTime.Now,
                    _CurrentApplication.Context.Request.Url.ToString(),
                    _CurrentApplication.Context.Request.UserAgent,
                    _CurrentApplication.Context.Request.UserHostAddress);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception: " + ex.Message);
            }
        }
    }
}
