﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class LinqDataSourceTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void detailEmployee_ItemDeleted(object sender, DetailsViewDeletedEventArgs e)
    {
        gridEmployees.SelectedIndex = -1;
        gridEmployees.DataBind();
    }

    protected void detailEmployee_ModeChanged(object sender, EventArgs e)
    {
        if (detailsEmployee.CurrentMode == DetailsViewMode.Insert)
        {
            gridEmployees.SelectedIndex = -1;
        }
    }
    protected void detailsEmployee_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {
        if (e.Exception != null)
        {
            LinqDataSourceValidationException linqException = e.Exception as LinqDataSourceValidationException;
            if (linqException == null)
            {
                lblError.Text = "Data error.";
            }
            else
            {
                lblError.Text = "";
                foreach (Exception err in linqException.InnerExceptions.Values)
                    lblError.Text += err.Message + "<br />";
            }

            e.ExceptionHandled = true;
        }
        else
        {
            gridEmployees.DataBind();
        }
    }
    protected void detailsEmployee_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
    {
        if (e.Exception != null)
        {
            LinqDataSourceValidationException linqException = e.Exception as LinqDataSourceValidationException;
            if (linqException == null)
            {
                lblError.Text = "Data error.";
            }
            else
            {
                lblError.Text = "";
                foreach (Exception err in linqException.InnerExceptions.Values)
                    lblError.Text += err.Message + "<br />";
            }
            
            e.ExceptionHandled = true;
        }
        else
        {
            gridEmployees.DataBind();
        }
    }
    protected void gridEmployees_SelectedIndexChanged(object sender, EventArgs e)
    {        
        detailsEmployee.ChangeMode(DetailsViewMode.ReadOnly);
    }
}
