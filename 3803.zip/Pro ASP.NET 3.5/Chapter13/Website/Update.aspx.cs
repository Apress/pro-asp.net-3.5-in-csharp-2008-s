﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.Linq;
using DatabaseComponent;
using System.Web.Configuration;

public partial class Update : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;
        DataContext dataContext = new DataContext(connectionString);

        Table<EmployeeDetails> employees = dataContext.GetTable<EmployeeDetails>();
        employees.First().FirstName = "New Name";

        EmployeeDetails newEmployee = new EmployeeDetails(342, "Rakesh", "Ramaranja", "Mr.");
        employees.InsertOnSubmit(newEmployee);

        EmployeeDetails removedEmployee = employees.Single(employee => employee.EmployeeID == 3);
        employees.DeleteOnSubmit(removedEmployee);

        employees.DeleteAllOnSubmit<EmployeeDetails>(from employee in employees 
                            where employee.LastName.StartsWith("F")
                                select employee);

        ChangeSet changes = dataContext.GetChangeSet();
        gridModified.DataSource = changes.Updates;
        gridAdded.DataSource = changes.Inserts;
        gridRemoved.DataSource = changes.Deletes;
        this.DataBind();        
    }
}
